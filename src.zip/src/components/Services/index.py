from fastapi import FastAPI, HTTPException, Request, Depends
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
import pyodbc
import os
from datetime import datetime, timedelta
import logging
from typing import Optional, List, Dict, Any
from pydantic import BaseModel
from dotenv import load_dotenv
import uvicorn

# Load environment variables
load_dotenv()

app = FastAPI(title="Attendance API", version="1.0.0")

# Enhanced CORS for AWS deployment
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://15.207.151.197:3000",
        "http://15.207.151.197:5000",
    ],
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    allow_headers=["Content-Type", "Authorization"]
)

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Pydantic models
class DepartmentResponse(BaseModel):
    id: int
    department_name: str

class EmployeeResponse(BaseModel):
    employee_id: str
    employee_name: str
    department_name: str

class AttendanceRequest(BaseModel):
    employeeId: str
    employeeName: str
    departmentName: str
    rating: int

class AttendanceRecord(BaseModel):
    id: int
    employee_id: str
    employee_name: str
    department: str
    rating: int
    ip_address: str
    check_in_time: datetime

class TimeStatusResponse(BaseModel):
    isPunchInAllowed: bool
    message: str
    currentTime: str
    serverTime: str
    timezone: str

class HealthResponse(BaseModel):
    success: bool
    message: str
    database: str
    timestamp: str
    clientIP: str
    punchInAllowed: bool
    timeStatus: str
    istTime: str
    timezone: str

# Database connection pool
connection_pool = None

def get_db_connection():
    conn = pyodbc.connect(
        'DRIVER={ODBC Driver 17 for SQL Server};'
        'SERVER=EC2AMAZ-Q6FD0CK\SQLEXPRESS;'
        'DATABASE=AttendanceDB;'
        'UID=sa;'  # SQL Server username
        'PWD=Ayaaz@1234;'  # SQL Server password
    )
    return conn

async def initialize_database():
    """Initialize database connection and verify table structure"""
    global connection_pool
    try:
        logger.info("Attempting to connect to SQL Server...")
        # Test connection
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT 1")
        logger.info("✅ Connected to SQL Server successfully!")
        
        await verify_table_structure(cursor)
        conn.close()
        
    except Exception as err:
        logger.error(f"❌ Database connection failed: {str(err)}")

async def verify_table_structure(cursor):
    """Verify and fix table structure"""
    try:
        # Check current table structure
        cursor.execute("""
            SELECT COLUMN_NAME, DATA_TYPE, IS_NULLABLE 
            FROM INFORMATION_SCHEMA.COLUMNS 
            WHERE TABLE_NAME = 'Attendance'
            ORDER BY ORDINAL_POSITION
        """)
        
        logger.info("📊 Current Attendance table structure:")
        for row in cursor.fetchall():
            logger.info(f"   - {row.COLUMN_NAME} ({row.DATA_TYPE})")

        # Add missing columns if needed
        columns = [row.COLUMN_NAME for row in cursor.fetchall()]
        
        if 'employee_id' not in columns:
            cursor.execute("ALTER TABLE Attendance ADD employee_id NVARCHAR(20) NULL")
            logger.info("✅ Added employee_id column")
        
        if 'department' not in columns:
            cursor.execute("ALTER TABLE Attendance ADD department NVARCHAR(50) NULL")
            logger.info("✅ Added department column")
        
        if 'rating' not in columns:
            cursor.execute("ALTER TABLE Attendance ADD rating INT NOT NULL DEFAULT 0")
            logger.info("✅ Added rating column")
        
        if 'ip_address' not in columns:
            cursor.execute("ALTER TABLE Attendance ADD ip_address NVARCHAR(45) NULL")
            logger.info("✅ Added ip_address column")

        # Create other tables if they don't exist
        await create_supporting_tables(cursor)
        
    except Exception as err:
        logger.error(f"Error verifying table structure: {err}")

async def create_supporting_tables(cursor):
    """Create supporting tables"""
    try:
        # Create Departments table if not exists
        cursor.execute("""
            IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='Departments' AND xtype='U')
            CREATE TABLE Departments (
                id INT IDENTITY(1,1) PRIMARY KEY,
                department_name NVARCHAR(50) NOT NULL UNIQUE,
                created_at DATETIME2 DEFAULT GETDATE()
            )
        """)

        # Create Employees table if not exists
        cursor.execute("""
            IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='Employees' AND xtype='U')
            CREATE TABLE Employees (
                id INT IDENTITY(1,1) PRIMARY KEY,
                employee_id NVARCHAR(20) NOT NULL UNIQUE,
                employee_name NVARCHAR(100) NOT NULL,
                department_id INT NOT NULL,
                is_active BIT DEFAULT 1,
                created_at DATETIME2 DEFAULT GETDATE(),
                FOREIGN KEY (department_id) REFERENCES Departments(id)
            )
        """)

        # Insert sample data if tables are empty
        await insert_sample_data(cursor)
        
        logger.info("✅ All supporting tables are ready")
    except Exception as err:
        logger.error(f"Error creating supporting tables: {err}")

async def insert_sample_data(cursor):
    """Insert sample data"""
    try:
        # Check if departments table is empty
        cursor.execute("SELECT COUNT(*) as count FROM Departments")
        dept_count = cursor.fetchone()[0]
        if dept_count == 0:
            cursor.execute("""
                INSERT INTO Departments (department_name) VALUES 
                ('Human Resources'),
                ('Information Technology'),
                ('Finance'),
                ('Marketing'),
                ('Operations'),
                ('Sales')
            """)
            logger.info("✅ Sample departments inserted")

        # Check if employees table is empty
        cursor.execute("SELECT COUNT(*) as count FROM Employees")
        emp_count = cursor.fetchone()[0]
        if emp_count == 0:
            cursor.execute("""
                INSERT INTO Employees (employee_id, employee_name, department_id) VALUES
                ('HR001', 'John Smith', 1),
                ('HR002', 'Sarah Johnson', 1),
                ('IT001', 'Mike Davis', 2),
                ('IT002', 'Emily Chen', 2),
                ('IT003', 'David Wilson', 2),
                ('FIN001', 'Lisa Brown', 3),
                ('FIN002', 'Robert Taylor', 3),
                ('MKT001', 'Jennifer Lee', 4),
                ('OPS001', 'James Miller', 5),
                ('SAL001', 'Patricia Moore', 6)
            """)
            logger.info("✅ Sample employees inserted")
            
    except Exception as err:
        logger.error(f"Error inserting sample data: {err}")

# Function to get client IP address
def get_client_ip(request: Request) -> str:
    forwarded = request.headers.get('x-forwarded-for')
    if forwarded:
        ips = forwarded.split(',')
        return ips[0].strip()
    
    real_ip = request.headers.get('x-real-ip')
    if real_ip:
        return real_ip
    
    client_ip = request.headers.get('x-client-ip')
    if client_ip:
        return client_ip
    
    cf_connecting_ip = request.headers.get('cf-connecting-ip')
    if cf_connecting_ip:
        return cf_connecting_ip
    
    if request.client:
        return request.client.host
    
    return 'Unknown'

# Request logging middleware
@app.middleware("http")
async def log_requests(request: Request, call_next):
    client_ip = get_client_ip(request)
    logger.info(f"{datetime.now().isoformat()} - IP: {client_ip} - {request.method} {request.url}")
    response = await call_next(request)
    return response

# Function to get current time in IST (India Standard Time)
def get_current_ist_time():
    now = datetime.utcnow()
    
    # Convert to IST (UTC+5:30)
    ist_offset = timedelta(hours=5, minutes=30)
    ist_time = now + ist_offset
    
    return {
        'hour': ist_time.hour,
        'minute': ist_time.minute,
        'second': ist_time.second,
        'formatted': ist_time.strftime('%H:%M:%S'),
        'fullDate': ist_time.isoformat()
    }

# Function to check if current time is within allowed punch-in time (09:00 to 09:45 IST)
def is_within_punch_in_time():
    ist_time = get_current_ist_time()
    current_hour = ist_time['hour']
    current_minute = ist_time['minute']
    
    # Allow punch-in only between 09:00 and 09:45 IST
    is_within_time = (current_hour == 9 and current_minute >= 0 and current_minute <= 45)
    
    logger.info(f"🕒 IST Time: {ist_time['formatted']}, Within allowed time: {is_within_time}")
    return is_within_time

# Function to get current time status message
def get_time_status_message():
    ist_time = get_current_ist_time()
    current_hour = ist_time['hour']
    current_minute = ist_time['minute']
    
    if current_hour < 9:
        return f"Punch-in will open at 09:00 AM IST. Current time: {ist_time['formatted']}"
    elif current_hour == 9 and current_minute <= 45:
        return f"Punch-in allowed until 09:45 AM IST. Current time: {ist_time['formatted']}"
    

# Check if employee already checked in today
async def has_employee_checked_in_today(employee_id: str, cursor) -> bool:
    try:
        cursor.execute("""
            SELECT COUNT(*) as checkInCount 
            FROM Attendance 
            WHERE employee_id = ? 
            AND check_in_date = CAST(GETDATE() AS DATE)
        """, employee_id)
        
        result = cursor.fetchone()
        return result[0] > 0
    except Exception as err:
        logger.error(f"Error checking duplicate attendance: {err}")
        return False

# Check if IP address already checked in today
async def has_ip_checked_in_today(ip_address: str, cursor) -> bool:
    try:
        cursor.execute("""
            SELECT COUNT(*) as checkInCount 
            FROM Attendance 
            WHERE ip_address = ? 
            AND check_in_date = CAST(GETDATE() AS DATE)
        """, ip_address)
        
        result = cursor.fetchone()
        return result[0] > 0
    except Exception as err:
        logger.error(f"Error checking IP duplicate: {err}")
        return False

# API Routes
@app.get("/api/departments", response_model=Dict[str, Any])
async def get_departments():
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT id, department_name 
            FROM Departments 
            ORDER BY department_name
        """)
        
        departments = []
        for row in cursor.fetchall():
            departments.append({
                'id': row.id,
                'department_name': row.department_name
            })
        
        conn.close()
        return {'success': True, 'data': departments}
        
    except Exception as err:
        logger.error(f"Error fetching departments: {err}")
        raise HTTPException(status_code=500, detail="Failed to fetch departments")

@app.get("/api/employees/{department_id}", response_model=Dict[str, Any])
async def get_employees(department_id: int):
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT e.employee_id, e.employee_name, d.department_name
            FROM Employees e
            INNER JOIN Departments d ON e.department_id = d.id
            WHERE e.department_id = ? AND e.is_active = 1
            ORDER BY e.employee_name
        """, department_id)
        
        employees = []
        for row in cursor.fetchall():
            employees.append({
                'employee_id': row.employee_id,
                'employee_name': row.employee_name,
                'department_name': row.department_name
            })
        
        conn.close()
        return {'success': True, 'data': employees}
        
    except Exception as err:
        logger.error(f"Error fetching employees: {err}")
        raise HTTPException(status_code=500, detail="Failed to fetch employees")

@app.post("/api/attendance")
async def record_attendance(attendance: AttendanceRequest, request: Request):
    try:
        client_ip = get_client_ip(request)
        
        logger.info(f"📱 Attendance attempt - Employee: {attendance.employeeName} ({attendance.employeeId}), Department: {attendance.departmentName}, IP: {client_ip}")
        
        # Check if within allowed punch-in time
        if not is_within_punch_in_time():
            time_message = get_time_status_message()
            raise HTTPException(status_code=400, detail=f"Punch-in not allowed. {time_message}")
        
        if not attendance.employeeId or not attendance.employeeName or not attendance.departmentName:
            raise HTTPException(status_code=400, detail="Employee selection is required")
        
        if not attendance.rating or attendance.rating < 1 or attendance.rating > 5:
            raise HTTPException(status_code=400, detail="Valid rating (1-5 stars) is required")

        conn = get_db_connection()
        cursor = conn.cursor()

        # Check if employee already checked in today
        employee_already_checked_in = await has_employee_checked_in_today(attendance.employeeId, cursor)
        if employee_already_checked_in:
            conn.close()
            raise HTTPException(
                status_code=400, 
                detail=f"{attendance.employeeName} ({attendance.employeeId}) has already checked in today. Duplicate punch-in is not allowed."
            )

        # Check if IP address already checked in today
        ip_already_checked_in = await has_ip_checked_in_today(client_ip, cursor)
        if ip_already_checked_in:
            conn.close()
            raise HTTPException(
                status_code=400, 
                detail=f"This device (IP: {client_ip}) has already been used to check in today. Each device can only check in once per day."
            )

        # Insert attendance record
        cursor.execute("""
            INSERT INTO Attendance (employee_id, employee_name, department, rating, ip_address, check_in_time, check_in_date)
            VALUES (?, ?, ?, ?, ?, GETDATE(), CAST(GETDATE() AS DATE))
        """, attendance.employeeId, attendance.employeeName, attendance.departmentName, attendance.rating, client_ip)
        
        conn.commit()
        conn.close()
        
        logger.info(f"✅ Attendance recorded - Employee: {attendance.employeeName} ({attendance.employeeId}), Department: {attendance.departmentName}, IP: {client_ip}")
        
        return {
            'success': True,
            'message': 'Attendance and rating recorded successfully',
            'data': {
                'employeeId': attendance.employeeId,
                'employeeName': attendance.employeeName,
                'departmentName': attendance.departmentName,
                'rating': attendance.rating,
                'ipAddress': client_ip,
                'checkInTime': datetime.now().isoformat()
            }
        }
        
    except HTTPException:
        raise
    except Exception as err:
        logger.error(f"Error recording attendance: {err}")
        raise HTTPException(status_code=500, detail=f"Failed to record attendance: {str(err)}")

@app.get("/api/time-status", response_model=Dict[str, Any])
async def get_time_status():
    try:
        is_allowed = is_within_punch_in_time()
        message = get_time_status_message()
        ist_time = get_current_ist_time()
        
        return {
            'success': True,
            'data': {
                'isPunchInAllowed': is_allowed,
                'message': message,
                'currentTime': ist_time['formatted'],
                'serverTime': datetime.now().isoformat(),
                'timezone': 'IST (UTC+5:30)'
            }
        }
    except Exception as err:
        logger.error(f"Error in time-status endpoint: {err}")
        raise HTTPException(status_code=500, detail="Error checking time status")

@app.get("/api/attendance/today", response_model=Dict[str, Any])
async def get_today_attendance():
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT id, employee_id, employee_name, department, rating, ip_address, check_in_time
            FROM Attendance 
            WHERE check_in_date = CAST(GETDATE() AS DATE)
            ORDER BY check_in_time DESC
        """)
        
        attendance_records = []
        for row in cursor.fetchall():
            attendance_records.append({
                'id': row.id,
                'employee_id': row.employee_id,
                'employee_name': row.employee_name,
                'department': row.department,
                'rating': row.rating,
                'ip_address': row.ip_address,
                'check_in_time': row.check_in_time
            })
        
        conn.close()
        return {'success': True, 'data': attendance_records}
        
    except Exception as err:
        logger.error(f"Error fetching today's attendance: {err}")
        raise HTTPException(status_code=500, detail="Failed to fetch today's attendance")

@app.get("/api/health", response_model=Dict[str, Any])
async def health_check(request: Request):
    try:
        # Test database connection
        db_status = "connected"
        try:
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute("SELECT 1")
            conn.close()
        except:
            db_status = "disconnected"
        
        client_ip = get_client_ip(request)
        is_punch_in_allowed = is_within_punch_in_time()
        time_message = get_time_status_message()
        ist_time = get_current_ist_time()
        
        return {
            'success': True,
            'message': 'Server is running',
            'database': db_status,
            'timestamp': datetime.now().isoformat(),
            'clientIP': client_ip,
            'punchInAllowed': is_punch_in_allowed,
            'timeStatus': time_message,
            'istTime': ist_time['formatted'],
            'timezone': 'IST'
        }
    except Exception as err:
        logger.error(f"Health check error: {err}")
        raise HTTPException(status_code=500, detail="Health check failed")

# Startup event
@app.on_event("startup")
async def startup_event():
    await initialize_database()

# Main entry point
if __name__ == "__main__":
    port = int(os.getenv('PORT', 5000))
    
    ist_time = get_current_ist_time()
    logger.info(f"🚀 Starting FastAPI server on port {port}")
    logger.info(f"📍 Access via: http://15.207.151.197:{port}")
    logger.info(f"🕒 Current IST Time: {ist_time['formatted']}")
    logger.info(f"🕒 Punch-in allowed: 09:00 AM - 09:45 AM IST")
    logger.info(f"📊 Health check: http://15.207.151.197:{port}/api/health")
    logger.info(f"⏰ Time status: http://15.207.151.197:{port}/api/time-status")
    
    uvicorn.run(
        app,
        host="0.0.0.0",
        port=port,
        log_level="info"
    )